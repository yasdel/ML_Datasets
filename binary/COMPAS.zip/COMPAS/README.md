Use pandas read_csv function to load data directly from the following link:
https://raw.githubusercontent.com/propublica/compas-analysis/master/compas-scores-two-years.csv
